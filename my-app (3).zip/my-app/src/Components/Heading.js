import React from 'react'

function WelcomeHeading(props) {
  return <h1>{props.headingText}</h1>;
}

export default WelcomeHeading;