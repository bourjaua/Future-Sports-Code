import React from 'react'

function MainText(props) {
  return <p>{props.mainText}</p>;
}

export default MainText;